<?php
namespace Awz\Bx24lead\Access\Custom;

use Awz\Bx24lead\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}