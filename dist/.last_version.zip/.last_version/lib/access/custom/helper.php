<?php
namespace Awz\Bx24lead\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}