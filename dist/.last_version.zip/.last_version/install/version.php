<?
$arModuleVersion = array(
	"VERSION" => "1.1.3",
	"VERSION_DATE" => "2025-06-14 10:41:00"
);
?>