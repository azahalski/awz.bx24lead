<?
$arModuleVersion = array(
	"VERSION" => "1.1.0",
	"VERSION_DATE" => "2022-07-04 13:48:00"
);
?>