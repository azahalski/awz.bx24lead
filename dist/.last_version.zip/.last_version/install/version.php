<?
$arModuleVersion = array(
	"VERSION" => "1.1.8",
	"VERSION_DATE" => "2025-07-11 13:23:00"
);
?>