<?
$arModuleVersion = array(
	"VERSION" => "1.1.6",
	"VERSION_DATE" => "2025-06-24 13:40:00"
);
?>