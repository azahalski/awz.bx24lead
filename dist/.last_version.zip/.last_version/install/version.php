<?
$arModuleVersion = array(
	"VERSION" => "1.1.4",
	"VERSION_DATE" => "2025-06-14 10:41:00"
);
?>