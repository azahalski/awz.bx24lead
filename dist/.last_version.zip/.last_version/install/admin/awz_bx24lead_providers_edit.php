<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.bx24lead/admin/providers_edit.php");