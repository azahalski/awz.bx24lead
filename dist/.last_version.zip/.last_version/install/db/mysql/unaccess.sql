drop table if exists awz_bx24lead_role;
drop table if exists awz_bx24lead_role_relation;
drop table if exists awz_bx24lead_permission;